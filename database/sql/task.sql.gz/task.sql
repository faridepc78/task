-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 27, 2021 at 02:31 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task`
--

-- --------------------------------------------------------

--
-- Table structure for table `lotteries`
--

CREATE TABLE `lotteries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lotteries`
--

INSERT INTO `lotteries` (`id`, `code`, `user_id`, `created_at`, `updated_at`) VALUES
(4, '3147755077', 1, '2021-12-26 23:16:40', '2021-12-26 23:16:40'),
(5, '4673623333', 10, '2021-12-26 23:27:51', '2021-12-26 23:27:51'),
(6, '4077372193', 5, '2021-12-26 23:28:00', '2021-12-26 23:28:00'),
(7, '8088340515', 11, '2021-12-26 23:52:50', '2021-12-26 23:52:50'),
(8, '7253350184', 15, '2021-12-26 23:53:33', '2021-12-26 23:53:33'),
(9, '6741226798', 13, '2021-12-26 23:53:41', '2021-12-26 23:53:41'),
(10, '7401043853', 14, '2021-12-26 23:53:54', '2021-12-26 23:53:54'),
(11, '6253693197', 19, '2021-12-26 23:54:04', '2021-12-26 23:54:04'),
(12, '4311930215', 17, '2021-12-26 23:54:12', '2021-12-26 23:54:12'),
(13, '2719489910', 3, '2021-12-26 23:54:20', '2021-12-26 23:54:20'),
(15, '524814884', 8, '2021-12-27 00:03:44', '2021-12-27 00:03:44'),
(16, '9931394572', 6, '2021-12-27 01:09:36', '2021-12-27 01:09:36');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(3, '2014_10_12_000000_create_users_table', 1),
(4, '2021_12_26_194131_create_lotteries_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `f_name` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `l_name` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `f_name`, `l_name`, `email`, `role`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'فرید', 'شیشه بری', 'faridnewepc78@gmail.com', 'admin', '$2y$10$pSykSU1fmDWCV5YZfqqF..A9LmJFhL2YUaBP3C35jNKwfsLZzhJdO', 'kJcNoSo7qblBzmzTEOs1tRXPWGKPjfPMjmoihqMzYKK4hwL7XWWohqninXuH', '2021-12-26 19:29:38', '2021-12-26 19:29:38'),
(3, 'آذرداد', 'مجتهد', 'katayoun97@example.org', 'user', '$2y$10$z.1nWQIo3Z5OMh4yltxbxeytyFYqJ.efocZBFM0BE21UmrOtW/qRu', NULL, '2021-12-26 19:29:40', '2021-12-26 19:29:40'),
(4, 'دینه', 'فرامرزی', 'husseini.mahshid@example.com', 'user', '$2y$10$D/AHLzMSiTdItSGOV2eLzOePd/ckJSG9..uGnZku37S3eWHKLq9Q6', NULL, '2021-12-26 19:29:40', '2021-12-26 19:29:40'),
(5, 'شادمهر', 'عبدالملکی', 'rahmani.mazdak@example.net', 'user', '$2y$10$NreYCV0PwNpuCV/KP8lai.TPtKEverk0YsbVr1iXMhqnkfmKHGfra', NULL, '2021-12-26 19:29:40', '2021-12-26 19:29:40'),
(6, 'آسیه', 'بزرگی', 'arash31@example.com', 'user', '$2y$10$KCo3UkTD9OPGRD4yn/Dfge6bg4YT6mhAISNs8jqngpYM4ncXGNynu', NULL, '2021-12-26 19:29:40', '2021-12-26 19:29:40'),
(7, 'آوین', 'زین‌الدین', 'kourosh53@example.com', 'user', '$2y$10$MoBf/1LQquiYdxRAMsFacuRNgq1xS28.aHT..98uU0RziiklFi.fm', NULL, '2021-12-26 19:29:40', '2021-12-26 19:29:40'),
(8, 'فتّانه', 'افخم', 'wtalebi@example.net', 'user', '$2y$10$Gzag0hqONgi5jT5zZU06e.D4v7EVPf1cRfQU1CZ7IfoxHgnbypEkO', NULL, '2021-12-26 19:29:40', '2021-12-26 19:29:40'),
(9, 'مهرام', 'مرادخانی', 'uhamidi@example.net', 'user', '$2y$10$..XUURc2gMwPZ3eYuWoV2uWAHuzmwLq8ti18WuwYxlAGR./uLQIdS', NULL, '2021-12-26 19:29:40', '2021-12-26 19:29:40'),
(10, 'سهند', 'طبیب‌زاده', 'kiana17@example.org', 'user', '$2y$10$Kj0YOJ5VtJNeKVR1MRPXDOaIBINYfv3XdMScvNG1DchjStJl7GUyi', NULL, '2021-12-26 19:29:40', '2021-12-26 19:29:40'),
(11, 'قباد', 'مستوفی', 'soheila78@example.net', 'user', '$2y$10$RCJ34p/u2UOiiNkw3iq61eeEcRjPSA51FtcT5rt5ymbr4C1K2kKmy', NULL, '2021-12-26 19:29:40', '2021-12-26 19:29:40'),
(13, 'Mohammad Rosario', 'Nicholas Pittman', 'xewidizuge@mailinator.com', 'user', '$2y$10$KTF6zGDW7FlTIMCQQlm5cuQ4cPVNwNLzdiBDYIVoNoGCZ3xjBqLC2', NULL, '2021-12-26 21:00:31', '2021-12-26 21:00:31'),
(14, 'Jeremy Knox', 'Gwendolyn Trujillo', 'ruqag@mailinator.com', 'user', '$2y$10$mxsLEsToqJelQD.zVfT/weppeRweArtPSidXvtCCmbCpRFknhW//i', NULL, '2021-12-26 21:01:00', '2021-12-26 21:01:00'),
(15, 'Talon Fulton', 'Geraldine Lee', 'xaso@mailinator.com', 'user', '$2y$10$fU9bRU2jb4HK7ckmBTRKy.L/AT78kUBfRiwQ.5sMGwliwSq1J5U26', NULL, '2021-12-26 21:02:10', '2021-12-26 21:02:10'),
(16, 'Alvin Mullins', 'Ciaran Marquez', 'cuhetu@mailinator.com', 'user', '$2y$10$2nh7aihMxQG5mU1becDqQex.r0qk2uAYL.rQfsTfMC3/7AnkfV3ym', NULL, '2021-12-26 21:02:20', '2021-12-26 21:02:20'),
(17, 'Hasad Cunningham', 'Nathan Glover', 'felakaz@mailinator.com', 'user', '$2y$10$c7bgOjicmAL3VC2qFUUHUuzij/obGp2AaT.eXhZHJxG1ChCdyrtYC', NULL, '2021-12-26 21:02:23', '2021-12-26 21:02:23'),
(18, 'Madison Austin', 'Leo Burris', 'fataf@mailinator.com', 'user', '$2y$10$7TcZMIjhHGr/25ivjTefTu4GmgKSwmwzm4yU5d7sfkfbO1wo/JcuS', NULL, '2021-12-26 21:02:29', '2021-12-26 21:02:29'),
(19, 'Linda Juarez', 'Amal Woodward', 'zysikih@mailinator.com', 'user', '$2y$10$XI13B0qKwUeyLcbC65eKKO/VHu6fyd9jozjHjkF0xgneEadSZYYPm', NULL, '2021-12-26 21:02:32', '2021-12-26 21:02:32'),
(20, 'Trevor Hobbs', 'Charity Neal', 'dowipetike@mailinator.com', 'user', '$2y$10$xPqvNVAenHOQzUf0Y6JXa.4p.GPPOXa3HKuHyooAh.AJdq251qseC', NULL, '2021-12-26 21:02:39', '2021-12-26 21:02:39'),
(21, 'Callum Noble', 'Norman Mclaughlin', 'wudogyqehy@mailinator.com', 'user', '$2y$10$tkQgjCZxDMyWFakbNX0rdOh43SjAtcJPxFpMTegCjtHGIZO6E7tia', NULL, '2021-12-26 21:02:45', '2021-12-26 21:02:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lotteries`
--
ALTER TABLE `lotteries`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `lotteries_code_unique` (`code`),
  ADD UNIQUE KEY `lotteries_user_id_unique` (`user_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_f_name_unique` (`f_name`),
  ADD UNIQUE KEY `users_l_name_unique` (`l_name`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lotteries`
--
ALTER TABLE `lotteries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `lotteries`
--
ALTER TABLE `lotteries`
  ADD CONSTRAINT `lotteries_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
